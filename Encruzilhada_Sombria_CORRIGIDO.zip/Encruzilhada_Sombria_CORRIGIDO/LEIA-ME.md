# Encruzilhada Sombria — versão corrigida

Jogo de tabuleiro estilo Ludo, para **duas pessoas no mesmo computador**, feito em Python com Pygame.

## Como abrir no Windows

1. **Extraia o arquivo ZIP inteiro** para uma pasta, sem mover `jogo.py` para fora dela. As imagens e os arquivos de áudio precisam ficar juntos do código.
2. Tenha o **Python 3.12 ou 3.13** instalado. Caso precise instalar, obtenha no site oficial: <https://www.python.org/downloads/>. Na instalação, marque a opção para adicionar o Python ao `PATH` quando disponível.
3. Dê dois cliques em **`iniciar_jogo.bat`**. O iniciador procura uma versão compatível do Python, instala o Pygame caso seja necessário (requer internet na primeira vez) e abre o jogo.

**Alternativa pelo terminal** (Prompt de Comando, aberto dentro da pasta do jogo):

```bat
py -3.13 -m pip install -r requirements.txt
py -3.13 jogo.py
```

Se tiver Python 3.12, substitua `-3.13` por `-3.12`. Também pode usar `python` no lugar de `py -3.13` quando essa for sua instalação correta.

## Controles

- **Enter** na tela inicial: iniciar a partida com os nomes informados.
- **Tab**: alternar entre os campos de nome.
- **Espaço** ou botão na interface: lançar o dado.
- **1, 2, 3 ou 4** ou clique: selecionar uma peça para movimentar.
- **S**: salvar a partida.
- **L**: carregar a última partida salva.
- **R**: reiniciar a partida, mantendo os nomes e o ranking.
- **N**: voltar à escolha dos nomes.
- **M**: ligar/desligar a música.
- **H**: abrir ou fechar o manual (o cronômetro é pausado enquanto o manual estiver aberto).
- **Esc**: fechar o manual ou sair do jogo.

O jogador tem **30 segundos** para escolher uma peça depois de lançar o dado. Ao tirar **6**, joga novamente. Para tirar uma peça da base, também é necessário tirar 6. Vence quem levar todas as quatro peças à chegada.

## Arquivos e persistência

- `jogo.py`: código principal do jogo.
- `fundo_gotico.png`, `musica_terror.mp3`, `som_dado.mp3`: recursos visuais e sonoros, preservados do projeto original.
- `salvamento_encruzilhada.json`: último salvamento (mantido do ZIP recebido).
- `ludo_ranking.json`: vitórias registradas (mantido do ZIP recebido).
- `requirements.txt`: dependência necessária para executar o jogo.

**Importante:** os arquivos JSON são escritos na própria pasta. Para salvar e carregar normalmente, coloque o jogo em uma pasta na qual seu usuário tenha permissão de escrita, como Documentos.

O jogo pode ser aberto **sem áudio** se o dispositivo ou o driver de som não estiver disponível. Nesse caso, os efeitos/música não serão reproduzidos, mas a partida continua funcionando.

## Correções realizadas

- Caminho do efeito sonoro do dado corrigido; todos os recursos são procurados na pasta de `jogo.py`.
- Inicialização de áudio protegida contra falhas de dispositivo, driver e arquivo ausente.
- Cronômetro da jogada inicializado e preservado ao salvar/carregar; pausa ao abrir o manual.
- Carregamento de JSON validado para evitar partidas inválidas e erros inesperados.
- Lógica de resultados sem movimento corrigida para manter o turno quando sair 6.
- Cartas especiais de avanço/retrocesso limitadas à peça que realmente caiu na casa especial.
- Ranking de vitórias lido ao iniciar, atualizado ao ganhar e comparado sem diferenciar letras maiúsculas/minúsculas.
- Entrada de nomes consolidada e reinício de estado ao começar uma nova partida.
- Teclas bloqueadas enquanto o manual está aberto, evitando jogadas acidentais.
- Código isolado para permitir importação e testes sem iniciar automaticamente o loop gráfico.
- Pasta `.venv` original removida do pacote: ambientes virtuais são específicos de cada sistema e devem ser recriados localmente.

## Testes e limitações

Foram feitos testes automatizados de regras, captura, escudo, cartas, movimento, tela de início, ranking, salvamento, carregamento, pausa do cronômetro e simulação do ciclo de telas com substitutos de Pygame. **Não foi possível executar uma sessão gráfica real com Pygame neste ambiente**, porque o pacote não estava disponível para instalação. Caso apareça alguma mensagem de erro no seu computador, copie a mensagem completa para facilitar a identificação.
