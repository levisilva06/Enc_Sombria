@echo off
setlocal
cd /d "%~dp0"
title Encruzilhada Sombria

rem Preferir versoes de Python amplamente compativeis com o Pygame.
set "PYTHON_CMD="
py -3.13 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3.13"
    goto verificar
)
py -3.12 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3.12"
    goto verificar
)
py -3 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3"
    goto verificar
)
python --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=python"
    goto verificar
)

echo.
echo [ERRO] Python nao foi encontrado neste computador.
echo Instale o Python 3.12 ou 3.13 e execute este arquivo novamente.
echo Consulte o arquivo LEIA-ME.md para instrucoes.
pause
exit /b 1

:verificar
echo Verificando o Pygame...
%PYTHON_CMD% -c "import pygame" >nul 2>&1
if errorlevel 1 (
    echo O Pygame nao esta instalado. Tentando instalar...
    %PYTHON_CMD% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo [ERRO] Falha ao instalar o Pygame.
        echo Confira a internet e a versao do Python.
        echo Python 3.12 ou 3.13 sao as versoes recomendadas.
        pause
        exit /b 1
    )
)

echo Iniciando Encruzilhada Sombria...
%PYTHON_CMD% jogo.py
if errorlevel 1 (
    echo.
    echo Ocorreu um erro ao executar o jogo.
    pause
    exit /b 1
)
exit /b 0
